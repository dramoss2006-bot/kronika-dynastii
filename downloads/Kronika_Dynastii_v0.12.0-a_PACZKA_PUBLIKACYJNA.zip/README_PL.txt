KRONIKA DYNASTII v0.12.0-a — WERSJA BETA
==========================================

Mod do Crusader Kings III współpracujący z programem Kronika Analyzer.

WYMAGANIA
---------
- Crusader Kings III
- Windows
- Kronika Analyzer v1.0.1
- zgodna wersja gry używana podczas testów projektu

INSTALACJA
----------
1. Rozpakuj plik Kronika_Dynastii_v0.12.0-a.zip.
2. Uruchom Install_Kronika_Dynastii.bat.
3. Potwierdź instalację w folderze modów CK3.
4. Uruchom launcher Paradox.
5. Dodaj „Kronika Dynastii - Rdzeń” do zestawu modów.
6. Uruchom grę.

INSTALACJA RĘCZNA
-----------------
Skopiuj:
- folder Kronika_Dynastii
- plik Kronika_Dynastii.mod

do:
Dokumenty\Paradox Interactive\Crusader Kings III\mod

TRYB DLA DWÓCH GRACZY
---------------------
- pierwszy gracz rejestruje się jako P1;
- drugi gracz rejestruje się jako P2;
- obaj gracze muszą używać tej samej wersji moda;
- Analyzer odczytuje raporty i wydarzenia z pliku debug.log.

WAŻNE
-----
Wersja zawiera decyzje diagnostyczne oznaczone [TEST].
Nie używaj ich w normalnej kampanii, chyba że wykonujesz kontrolowany test eksportu.

WERYFIKACJA
-----------
SHA-256:
4a70a2dd0440e52a261fdf01fed68827f4e19a543df4444c662bae85dba0063d

WERSJA
------
0.12.0-a beta
